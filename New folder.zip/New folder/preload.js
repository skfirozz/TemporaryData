const { contextBridge, ipcRenderer } = require('electron');

// Expose the `selectMode` function to the renderer process
contextBridge.exposeInMainWorld('api', {
    selectMode: (mode) => ipcRenderer.send('select-mode', mode),
});
