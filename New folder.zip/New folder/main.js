const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
        },
        frame: false, // Remove the standard frame to achieve a "floating" window effect
        transparent: true, // Enable transparency
        alwaysOnTop: true, // Ensure the window is always on top
        skipTaskbar: true, // Exclude the app from the taskbar
        resizable: false, // Disable resizing
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

// Handle app mode selection
ipcMain.on('select-mode', (event, mode) => {
    if (mode === 'isscreensharing') {
        // Set the window to "click-through" mode, visible only to the local user
        mainWindow.setIgnoreMouseEvents(true, { forward: true });
    } else if (mode === 'screennotsharing') {
        // Make the window interactive again
        mainWindow.setIgnoreMouseEvents(false);
    }
});

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});
