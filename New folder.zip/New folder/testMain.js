const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        alwaysOnTop: true, // Always on top of other windows
        resizable: true,   // Allow resizing
        movable: true,     // Allow dragging the window
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
        },
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

// Function to handle screen-sharing modes
ipcMain.on('select-mode', (event, mode) => {
    if (mode === 'isscreensharing') {
        enableScreenSharingExclusion();
    } else if (mode === 'screennotsharing') {
        disableScreenSharingExclusion();
    }
});

// Windows-specific: Exclude window from screen capture
function enableScreenSharingExclusion() {
    if (process.platform === 'win32') {
        const { exec } = require('child_process');
        const hwnd = mainWindow.getNativeWindowHandle().readInt32LE(0);

        // Use PowerShell to enable cloaking (excluding from screen share)
        exec(`powershell -Command "Add-Type @\"
            using System;
            using System.Runtime.InteropServices;
            public class DwmApi {
                [DllImport(\\"dwmapi.dll\\")]
                public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int attrSize);
            }
            \"@; 
            [DwmApi]::DwmSetWindowAttribute((New-Object IntPtr ${hwnd}), 14, [ref]1, 4)"`);
    }
}

// Windows-specific: Remove exclusion
function disableScreenSharingExclusion() {
    if (process.platform === 'win32') {
        const { exec } = require('child_process');
        const hwnd = mainWindow.getNativeWindowHandle().readInt32LE(0);

        // Use PowerShell to disable cloaking
        exec(`powershell -Command "Add-Type @\"
            using System;
            using System.Runtime.InteropServices;
            public class DwmApi {
                [DllImport(\\"dwmapi.dll\\")]
                public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int attrSize);
            }
            \"@; 
            [DwmApi]::DwmSetWindowAttribute((New-Object IntPtr ${hwnd}), 14, [ref]0, 4)"`);
    }
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});


/**
 * Im user I have to see the app messages clearly not like trasparent I dont compromise on seeing the window of my application, position as change, not closing when i use alt tab, 
but when I do screen sharing the entire window in the vedio call 
this window should not be detected in the vedio call and its messages everything it happends in the application.
do you understand
ChatGPT said:
ChatGPT
Got it! Here's a clear understanding of your requirements:

Visibility to You:

The app window should remain fully visible and non-transparent to you, with its messages clearly readable.
Behavior During Screen Sharing:

While you're in a video call and sharing your screen, the application window should not appear in the shared screen (hidden from the other participants).
You should still be able to see and interact with the app normally.
Window Behavior:

The app window should stay always on top and should not minimize or disappear when using Alt+Tab.
The position of the window should be adjustable by dragging, allowing flexibility to place it anywhere on the screen.
Solution Overview
We need to achieve the following:

Use platform-specific APIs to exclude the window from being captured during screen sharing. On Windows, this involves using a feature like Window Cloaking (via DWM), and on macOS, we can exclude the window from display capture.
Keep the application window always on top, fully visible, and interactive.
Ensure drag-and-drop repositioning of the window.
 */