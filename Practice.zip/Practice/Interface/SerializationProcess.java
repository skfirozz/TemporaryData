package Interface;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationProcess implements Serializable{

    private static final long serialVersionUID = 1L;

    int id;
    static String name;
    int deptNo;
    String gender;

    public SerializationProcess(int id, String name, int dep, String gen){
        this.id = id;
        this.name = name;
        this.deptNo = dep;
        this.gender = gen;
    }

    public String toString() {
        return "Employee {id=" + id + ", name=" + name + ", deptNo  "+deptNo +" , Gender  "+gender +"}";  
    }


    public static void main(String[] args) {
        // generateSerialization();
        Deserialization();

    }

    public static void generateSerialization(){
        SerializationProcess ss = new SerializationProcess(19,"helllo there", 29, "male");

        try{
            FileOutputStream file = new FileOutputStream("SerializartionFile.ser");
            ObjectOutputStream obj = new ObjectOutputStream(file);
            obj.writeObject(ss);
            obj.close();
            file.close();
        }catch(IOException e){
            System.out.println("exception occured     " +e.getMessage());
        }
    }

    public static void Deserialization(){

        try{
            FileInputStream fileIn = new FileInputStream("SerializartionFile.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            SerializationProcess emp = (SerializationProcess) in.readObject();
            in.close();
            fileIn.close();

            System.out.println("Deserialized Employee: " + emp);
        }catch(IOException | ClassNotFoundException  e){
            System.out.println("exception occured     " +e.getMessage());
        }
        
    }


}
