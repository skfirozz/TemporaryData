public class Pattern5 {
    public static void main(String[] args) {
        
        int number = 1;
        int array[][] = new int[number][number];

        int i_index = 1;
        int j_index = 1;

        while(true){
            array[i_index][j_index] = number++;
            if(j_index < array.length-1)
                j_index++;
            else if(j_index == array.length-1)
                i_index++;
            else if(i_index == array.length-1 && j_index == array.length -1)
                j_index--;
        }
        
    }
    
}
