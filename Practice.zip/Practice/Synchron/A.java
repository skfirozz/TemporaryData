package Synchron;

// public class A {
    
// }


public class A{
 
    A(){
        System.out.println("6");
    }

    static{
        System.out.println("1");
    }
     
    {
        System.out.println("2");
    }
     
    static void m1(){
        System.out.println("3");
    }
     
    static int j =4;
    int i =5;
     
    public static void main(String[] args){
        A a=new A();
        System.out.println(a.i);
    }

    {
        System.out.println(i);
    }
     
}
