package Synchron;

import java.util.Arrays;
import java.util.stream.Collectors;

public class DemoA {

    public static void main(String[] args) {
        reverseOfWord();
    }

    public static void reverseOfWord(){

        String str = "Hello Java programming";

        String res = Arrays.stream(str.split(" "))
                    .map(word -> new StringBuilder(word).reverse())
                    .collect(Collectors.joining(" "));

        System.out.println(res);
    }
}