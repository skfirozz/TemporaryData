package Tempo;

public class Sington {
    private static Sington instance;

    private Sington(){}

    
    public  static Sington getInstance(){

        if(instance == null){
            synchronized(Sington.class){
                if(instance == null)
                    instance = new Sington();
            }
        }

        return instance;
    }
    
}
