package Tempo;

public class LinkedList {

    private Node head;

    public void add(int data){
        if(head == null){
            head = new Node(data);
            return;
        }
        Node temp = head;
        while(temp.next != null){
            temp = temp.next;
        }
        temp.next = new Node(data);

    }

    


    
}

class Node{
    int data;
    Node next;

    Node(int da){
        this.data = da;
        this.next = null;
    }
}
