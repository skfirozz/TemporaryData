package Tempo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ProgramA {
    //list of integers and reverse the list array list
    
    public static void main(String[] args) {
        
        // countCharacters();
        // reveseOfWords();
        subStringProblem();
    }

    public static void reveseOfList(){
        List<Integer>  list = Arrays.asList(1,2,3,4,5);

        List<Integer> tempList = new ArrayList<>();
       
        for(int i =list.size()-1; i>=0; i--)
        {
            tempList.add(list.get(i));
        }
        System.out.println(tempList);
    }
    
    public static void countCharacters(){
        String str = "firoz";

        Map<Character, Long> map = str.chars()
                                        .mapToObj(c -> (char)c)
                                        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(map);

    }

    public static void reveseOfWords(){

        //
        String str = "I love java programming";

        String res = Arrays.stream(str.split(" "))
                            .map(word -> new StringBuilder(word).reverse())
                            .collect(Collectors.joining(" "));

        System.out.println(res);
    }

    public static void subStringProblem(){
        String str = "qualcomm";

        IntStream.rangeClosed(0, str.length()-1)
                .filter(i -> str.contains("comm") )
                .forEach(i -> System.out.println("exist") );

        // table of employee rows id, name , salary
        //select * from Employee where id % 2 ==0;
        // 100, 100, 100 , 90
        // Selct * from employee group by salary order by salary desc offset 1;

    }

}
