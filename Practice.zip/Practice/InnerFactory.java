import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class InnerFactory {


    public static void main(String[] args) {



        List<CSV> data = readData("C:\\Users\\shfiroz\\workFolder\\Practice\\banks.csv");
        // List<String> banks = new ArrayList<>();

        // data.stream()
        //     .collect(Collectors.groupingBy(
        //         CSV::getCountry, 
        //         new::ArrayList(CSV::getBankName)
        //     ));
        
        for (CSV csv : data) {
            System.out.println(csv.getBankName());
        }

    }

    public static List<CSV> readData(String fileName){

        List<CSV> data = new ArrayList<>();
        try{
            Scanner sc = new Scanner(new File(fileName));
            // sc.useDelimiter(",");

            while(sc.hasNext()){
                // System.out.println(sc.next());

                String[] temp = sc.next().split(",");
                System.out.println(temp.toString());
                // CSV c = new CSV(temp[0], temp[1], temp[2]);
                // data.add(c);
            }
            return data;
        }
        catch(FileNotFoundException  f){
            System.out.println(f.getMessage());
        }
        return null;

    }

}

class CSV{
    String bankName;
    String count;
    String country;

    public CSV(String name, String count, String country){
        bankName= name;
        this.count = count;
        this.country = country;
    }
    public String getBankName() {
        return bankName;
    }
    public String getCount() {
        return count;
    }
    public String getCountry() {
        return country;
    }
}





class AirTransport implements FactoryDP{

    @Override
    public void SendPackage() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'SendPackage'");
    }
    
}

class TrainTransport implements FactoryDP{

    @Override
    public void SendPackage() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'SendPackage'");
    }
    
}

 class RoadTransport implements FactoryDP{

    @Override
    public void SendPackage() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'SendPackage'");
    }
    
}



interface FactoryDP {

    void SendPackage();
    
}
