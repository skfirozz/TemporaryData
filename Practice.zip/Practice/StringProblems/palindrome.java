package StringProblems;

public class palindrome {
    public static void main(String[] args) {
        
    }

    public static boolean isPalindrome(String str){
        String temp = "";
        
        return false;
    }
}
