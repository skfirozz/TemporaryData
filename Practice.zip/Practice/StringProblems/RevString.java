package StringProblems;
class RevString{
    public static void main(String[] args) {
        String str = "hello there how are you";

        String temp = "";

        for(int i =0; i< str.length(); i++){
            temp =  str.charAt(i) + temp ;
        }
        System.out.println(temp);
    }
}