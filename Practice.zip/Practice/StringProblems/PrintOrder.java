package StringProblems;

import java.util.Stack;

public class PrintOrder {

    public static void main(String[] args) {
        String str = "3[a]2[bc]";
        funStack(str);
    }

    public static void funStack(String str){
        Stack<Character> stack = new Stack<>();
        Stack<Character> emptyStack = new Stack<>();


        for(char ch : str.toCharArray())
            stack.push(ch);
        // System.out.println(stack);

        String tempStr = "";
        int index = 0;
        while(true){
            System.out.println("index   " + index);
            System.out.println("tempy stack   " + emptyStack);
            index++;
            if(stack.peek() == ']'){
                emptyStack.push(stack.peek());
                stack.pop();
                continue;
            }
            else if(stack.peek() == '[' && !emptyStack.empty()){
                emptyStack.pop();
                stack.pop();
                if(!stack.empty() ){
                    int limit = Character.getNumericValue(stack.peek());
                    String temp = "";
                    for(int i =0; i< limit; i++){
                        temp = temp + tempStr;
                        System.out.println("temp    " + temp);
                    }
                    if(limit != 0) tempStr = tempStr + temp;  
                    stack.pop();
                }
            }
            if(!stack.empty()){
                tempStr = stack.peek() + tempStr;
                System.out.println("temp str   " + tempStr);
                stack.pop();
            }

            if(index > 10) break;
            
        }

    }

    public static void fun(String str){
        Stack<Character> stack = new Stack<>();

        for(char ch : str.toCharArray())
            stack.push(ch);
        System.out.println(stack);

        int index = 1;
        String tempStr = "";
        while(index > 0){
            System.out.println("indexx  " + index);
            index++;
            int limit = 0;
            System.out.println(stack);
            if(stack.peek() == ']'){
                stack.pop();
                continue;
            }
            else if( stack.peek() == '['){
                stack.pop();
                if(!stack.empty()) {
                    limit = Character.getNumericValue(stack.peek());
                    String temp = "";
                    for(int i =0; i<limit; i++)
                        temp = temp+tempStr;
                    System.out.println("limit   "+limit);
                    System.out.println("temp   " +temp);
                    stack.pop();
                }
            };
            tempStr = stack.peek()+tempStr;
            stack.pop();
            System.out.println("printing stack at end  " +stack);
            if(limit != 0)
                // tempStr = temp;
                break;
                
            System.out.println(tempStr);
            

            if(stack.empty()) break;
        }

    }
    
}
