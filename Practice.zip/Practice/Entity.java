public class Entity {


    public static void main(String[] args) {
        
        int array
    }

    
}


// // student and courses
// // 

// class Student{

//     private int id;
//     private String name;
//     private String classSection;
// //// timestamps
// }

// class Couses{

//     private int id;
//     private String courseName;
//     private int CourseDuration;
//     // timestamps
//     // private 
// }

// // @Entity("")
// class CourseRegistration{

//     @Id(GeneratedType.)
//     private int id;

//     @oneToMant()
//     private int userId;
    
    
//     private int courseId;
//     private int courseDuration;
//     private String created_at;
//     private String updated_at;
// }
