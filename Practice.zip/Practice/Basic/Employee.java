package Basic;

import java.util.Arrays;
import java.util.List;

public class Employee {

    int salary;
    String name;
    String title;

    

    public int getSalary() {
        return salary;
    }


    public String getName() {
        return name;
    }


    public String getTitle() {
        return title;
    }


    @Override
    public String toString() {
        return "Employee [salary=" + salary + ", name=" + name + ", title=" + title + "]";
    }


    public Employee(String nam, int sal, String tit){
        name = nam;
        salary = sal;
        title = tit;
    }


    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(new Employee("a", 0, "a"),
        new Employee("b", 10, "b")
        );

        // Map<String, Integer> map = new HashMap<>();

        // list.stream().collect(Collectors.toMap(i -> i.name, i.salary));
        
        list.stream().filter( obj -> obj.name.equals("a"));

        System.out.println(list.stream().filter( obj -> obj.name.equals("a")).toList());

    }

    
}


/*  REMInder on Interfaces.
    extending each other of the functional interfaces and how ambiguoty works .

 * 
*/