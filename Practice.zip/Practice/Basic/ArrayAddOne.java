package Basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayAddOne {

    public static void main(String[] args) {
        int array[] = { 9,9,9,9};
        // System.out.println(Arrays.toString(addition(array)));
        System.out.println(Arrays.toString(efficientWay(array)));
    }

    public static int[] addition(int array[]){
        int number = 0;
        int index = 0;
        while(index < array.length ){
            number = (number * 10) + array[index++];
        }
        number++;

        List<Integer> list = new ArrayList<>();
        while(number > 0){
            list.add(number %10);
            number = number /10;
        }
        Collections.reverse(list);
        return list.stream().mapToInt(i -> i).toArray();
    }
    
    public static int[] efficientWay(int array[]){
        int prev = 0;
        
        for(int i = array.length -1; i>=0; i--){
            if(array[i] < 9){
                array[i]++;
                prev = 0;
                break;
            }else if(array[i] == 9 ){
                array[i] = 0;
                prev = 1;
            }
        }
        if(prev == 1){
            array = new int[array.length +1];
            array[0] = 1;
        }
        return array;
    }
}
