package Basic;

import java.util.stream.IntStream;

public class JsonProgram {

    public static void main(String[] args) {
        
        int[] arr = {1,3,4,5,6,7,8,9};

        // int length = arr.length ;
        // int result = length * (length + 1) /2;

        // System.out.println("result  "+ result);
        int totalSum = IntStream.of(arr).sum();
        System.out.println(IntStream.rangeClosed(1, 9).map(i-> i).sum() - totalSum);;
        // System.out.println(totalSum);

        


    }


    public static void fun(Object obj){
    
        

    }

    
}
