package Basic;

import java.util.Arrays;

public class ShirftArrayValues {

    public static void main(String[] args) {
        
        int array[] = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16 };
        int target = 121;
        if( target <= 0) return;
        // int result[] = shiftArray(array, target);
        // findUnique();
        moveAllZerosToEnd();
        // System.out.println(Arrays.toString(result));
    }

    public static void reverseArray(int array[]){
        int tempArray[] = new int[array.length];
        for(int i =0; i< array.length; i++){
            // tempArray[i] 
        }
    }


    public static int[] shiftArray(int array[], int target){

        int tempArray[] = new int[array.length];
        for(int i = 0; i< array.length; i++){
            int newIndex =  (i + target) % array.length;
            tempArray[newIndex] = array[i];
        }
        return tempArray;

    }

    public static void moveAllZerosToEnd(){
        int array[] = {1,2,3,4,5,6,7,0,8,9, 0, 10,11,12, 0, 13,14,15,16};
        int tempArray[] = new int[array.length];
        int index = 0;
        for(int i = 0; i< array.length; i++){
            if(array[i] != 0){
                tempArray[index++] = array[i];
            }
        }

        int tempArrayEnd[] = new int[array.length];
        index = array.length-1;
        for(int i = array.length-1; i>=0; i--){
            if(array[i] != 0)
                tempArrayEnd[index--] = array[i];
        }
        System.out.println(Arrays.toString(tempArrayEnd));
    }



    public static void findUnique(){
        int array[] = {4, 1, 2, 1, 2, 4, 3};

        int unique = 0;
        for(int n : array)
        {
            unique = unique ^ n;
            System.out.println(unique);
        }
        System.out.println(unique);
    }
    
}
