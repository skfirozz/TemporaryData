package Basic;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BubbleSort {

    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();

        // list.stream()
        // .filter( i -> i.getDate().isAfter(LocalDate.now()) )
        // .collect(Collectors.groupingBy(i-> i.city(),  )); //new ArrayList()

    }


    public static void TreeFunction(){
        Map<Character, Integer> map = new HashMap<>();

        // TreeMap<Character, Integer> treeMap = new TreeMap<>(map); // key order

        // TreeMap<Character, Integer> treeMapValueBased = new TreeMap<>(); //


    }
    
}


class Employee{
    String name;
    String city;
    LocalDate date;

    public LocalDate getDate(){
        return date;
    }
// getters and setters
    // condition 1980 and from which city how mant employees available
}


// throwable exception in exception 
// try with resources.
// JPA provider how internally working the each and every annotation in JPA level


// id, name, deptNo , salary
// 1 firoz 1
// 2  Nilesh 3
// 3  H 1

// id, Name as dept table



/**  Select e.name, e1.name as managerName from Employee as e 
    INNER JOIN Employee as e1 ON e1.id = e.managerID
*/


/**  update SET salary = salary + 10
 * where id in 
 ( SELECT e.id from Employee as e
     INNER JOIN Dept as d ON d.id = e.deptNo 
       WHERE d.name = ''
  )
*/
