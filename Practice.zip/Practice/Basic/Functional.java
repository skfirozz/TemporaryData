package Basic;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public interface Functional {

    public static void main(String[] args) {
        
        List<User> users = Arrays.asList(
            new User("Alice", 30),
            new User("Bob", 22),
            new User("Charlie", 35)
        );

        Predicate<User> isAdults = us -> us.getAge() > 18;
        // isAdults.

        

    }
    
}

class User{
    String name;
    int age;

    User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name + " (" + age + " years old)";
    }
}
