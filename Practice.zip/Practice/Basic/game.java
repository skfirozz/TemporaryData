package Basic;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class game {

    public static void main(String[] args) {
        Random  rad = new Random();
        Scanner sc = new Scanner(System.in);
        int array1[] = new int[5];
        int array2[] = new int[5];
        int index1 = 0, index2 = 0; 
        // System.out.println("Enter *P* for Paper");
        // System.out.println("Enter *S* for Sizer");
        // System.out.println("Enter *R* for Rock");
        int customer = 0, computer = 0, cus = 0;
        char ch ='a';
        String data[] = {"null", "paper", "sizer", "rock"};

        int i = 0;
        while(i++ > 0){
            if(i %2 == 0)
            {
                System.out.println("Enter *P* for Paper");
                System.out.println("Enter *S* for Sizer");
                System.out.println("Enter *R* for Rock");
                System.out.println("enter your Choise  ");
                ch = sc.next().charAt(0); 
            }
            else
                {
                    cus = rad.nextInt(1,3);
                    System.out.println("computer choise is  " + data[cus]);
                    
                }
            
            if(ch == 'P'  && cus == 1){
                System.out.println("same ");
            }
            else if (ch == 'P' && cus > 1 )
                System.out.println("you lost ");
            else if(ch == 'S'  && cus == 2){
                System.out.println("same ");
            }
            else if (ch == 'S' && cus == 1 )
                System.out.println("you won ");
            else if(ch == 'R'  && cus == 3){
                System.out.println("same ");
            }
            else if (ch == 'R' && cus == 1 )
                System.out.println("you won ");
                
        }
        // System.out.println("your data :  "+Arrays.toString(array1));
        // System.out.println("Computer data is :  "+Arrays.toString(array2));

                
    }
}