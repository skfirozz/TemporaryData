package Basic;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Problem {

    public static void main(String[] args) {
    // pattern(5);
    //         list of employee 
    // name salray dept 
    // list filter based on largest salary in department

        List<Employe> list = Arrays.asList();

        System.out.println(list.stream()
        .collect(Collectors.groupingBy(Employe::getDeptNo, Collectors.maxBy(Comparator.comparing(Employe::getSalary)) )));

        // 
        // Map<Integer, Employe> map = new HashMap<>();
        // for (Employe employe : list) {
        //     if(map.containsKey(employe.getDeptNo())){

        //     }
        // }
    }


    // in employee table 
    // name, id, manager_id, dept_id

    /*
    SELECT e1.name, e2.name as manager_name, e1.id, e1.dept_id 
    FROM EMPLOYEE as e1
    INNER JOIN EMPLOYEE as e2 ON e2.id = e1.manager_id
    */  
    



    // public static 
    
    
}