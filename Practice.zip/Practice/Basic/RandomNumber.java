package Basic;

import java.util.Random;

public class RandomNumber {

    public static void main(String[] args) {

        Random random = new Random();
        for(int i =0; i< 15; i++){
            System.out.println(random.nextInt(-10, 10));
        }
    }

    public static int game(int achhu, int bomma){

        if(achhu > bomma)
            return 1;
        return 0;
    }
}
