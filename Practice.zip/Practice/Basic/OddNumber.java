package Basic;

public class OddNumber {
    
    public static void main(String[] args) {

        int number = 30;
        for(int i = 1; i<= number; i++){
            if(i%2 == 0)
                System.out.println(i);
        }
    }
}
