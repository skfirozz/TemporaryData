package Basic;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
// java language
public class Demo{
    public static void main(String[] args) {
        System.out.println("geyyyy");

        List<Employe> list = Arrays.asList(
            new Employe(1, "hrlloa", 10),
            new Employe(2, "b", 10),
            new Employe(3, "c", 10),
            new Employe(4, "d", 50),
            new Employe(5, "w", 50),
            new Employe(6, "s", 40),
            new Employe(7, "f", 40),
            new Employe(8, "ss", 20),
            new Employe(9, "ff", 10),
            new Employe(10, "h", 30),
            new Employe(11, "sss", 30),
            new Employe(12, "as", 20),
            new Employe(13, "bb", 10) );
            
            Map<Integer, List<Employe>> map = list.stream()
                                                    .collect(Collectors.groupingBy(i -> i.getDeptNo()));

            map.forEach((d, e) -> System.out.println(d +"   " + e));
    }

    public static void reverseOfWord(){
        String str = "hello there how are you";
        String res = Arrays.stream(str.split(" "))
                            .map(word -> new StringBuilder(word).reverse().toString())
                            .collect(Collectors.joining(" "));

        System.out.println(res);
    }
}


class Employe{

    int id;
    String name;
    int dept;
    int salary;

    public Employe(int no, String na, int dep){
        id = no;
        name = na;
        dept = dep;
    }
    public int getSalary(){
        return salary;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return name;
    }
    public int getDeptNo(){
        return dept;
    }

    @Override
    public String toString() {
        return "{id=" + id + ", name=" + name + ", dept=" + dept + "}";
    }
}