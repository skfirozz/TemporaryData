package Basic;

import java.util.HashMap;
import java.util.Map;

public class LongestNonRepeatedSubstring {

    public static int start = 0, maxLen = 0;

    public static void main(String[] args) {
        String str = "abcabcbbdcs";
        LongestPalindrome(str);
          
    } 
    
    public static String LongestSubString(String str ){
        Map<Character, Integer> map = new HashMap<>();
        int left = 0, maxLen = 0, start = 0;
        for(int right = 0; right < str.length(); right++){
            char ch = str.charAt(right);
            if(map.containsKey(ch)){
                left = Math.max(left, map.get(ch)+1);
            }
            map.put(ch, right);

            if(right - left + 1 > maxLen){
                maxLen = right - left +1;
                start = left;
            }
        }
        return str.substring(start, start+maxLen);
    }

    public static String LongestPalindrome(String str){
        for(int i = 0; i< str.length(); i++){
            expand(str, i, i);
            expand(str, i, i+1);
        }
        return str.substring(start, start + maxLen);
    }
    
    public static void expand(String str, int left, int right){
        while(left >= 0 && right < str.length() && str.charAt(right) == str.charAt(left)){
            left--;
            right++;
        }
        left++;right--;
        if(right - left + 1 > maxLen){
            maxLen = right - left+1;
            start = left;
        }
    }
}
