package Basic;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ColorGame {

    private static String[] colors = {"Red", "Blue", "Green", "Yellow", "Black"};

    public static void main(String[] args) {
        Map<String, Integer> map = new HashMap<>();
        Map<String, Map<String, Integer>> data = new HashMap<>();
        Scanner sc = new Scanner(System.in);


        while (true) {
            System.out.println("Do you want to continue game or not \n 1 ---> continue \n 0 ------> exit");
            
            if(sc.nextInt() == 0) break;
            
            System.out.println("Enter your name");
            String name = sc.next();

            System.out.println("Enter color:  ");
            String str = sc.next();
            System.out.println("Enter Amount : ");
            int value = sc.nextInt();
            Map<String, Integer> innerMap = new HashMap<>();
            innerMap.put(str, value);
            data.put(name, innerMap);


            if(map.containsKey(str)){
                map.put(str, map.get(str)+value);
            }
            else map.put(str, value);

            
        }

        System.out.println(map);
        System.out.println(data);
        int money = 0;
        String tempStr = "";
        int lowest = 1000000;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if(entry.getValue() > money  ){
                money = entry.getValue();
            }
            if(lowest > entry.getValue()){
                lowest = entry.getValue();
                tempStr = entry.getKey();
            }
        }

        System.out.println("lowest moeny is on   " + tempStr);
        System.out.println("the winner is  " + tempStr);

    }
}
