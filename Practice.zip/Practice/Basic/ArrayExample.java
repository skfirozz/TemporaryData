package Basic;

public class ArrayExample {
    public static void main(String[] args) {
        int array[] = {1,2,2,3,3,4,4,4,4,5,5,5,7,7};

        for(int i = 0; i< array.length; i++){
            int count = 0;
            int index = 0;
            for(int j = i; j< array.length; j++){
                if(array[ i] == array[j] ){
                    count++;
                    index = j;
                }
            }
            i = index;
            System.out.println(array[i] +"   " + count);
        }
    }
}
