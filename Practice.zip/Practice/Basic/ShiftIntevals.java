package Basic;

import java.util.ArrayList;

public class ShiftIntevals {

    public static void main(String[] args) {
        int[][] array = {{1,3},{3,4},{6,7},{8,9}};

        ArrayList<Integer> list = new ArrayList<>();
        for(int[] inteval : array){
            // System.out.println(inteval[0]);
            // System.out.println(inteval[1]);
            list.add(inteval[0]);
            list.add(inteval[1]);
        }
        ArrayList<Integer> tempList = list;
        for(int i= 1; i<list.size(); i++){
            System.out.println(list.get(i));
            if(list.get(i) == list.get(i-1)){
                tempList.remove(list.get(i));
            }
        }
        System.out.println(tempList);
    }
    
}
