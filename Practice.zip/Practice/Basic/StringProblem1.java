package Basic;

public class StringProblem1 {

    private static StringProblem1 instance;
    private StringProblem1(){}

    public static StringProblem1 getInstanceObject(){
        if(instance == null){
            synchronized(StringProblem1.class){
                if(instance == null){
                    instance = new StringProblem1();
                }
            }
        }
        return instance;
    }

    

}