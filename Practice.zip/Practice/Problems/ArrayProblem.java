package Problems;

public class ArrayProblem {

    /* Given an array of positive integers arr[] of size n, the task is to find second largest distinct element in the array.
 
Input: arr[] = [12, 35, 1, 10, 34, 1]
Output: 34
 
Input: arr[] = [10, 5, 10]
Output: 5
 
Input: arr[] = [10, 10, 10]
Output: -1
has context menu
    
    */

    public static void main(String[] args) {
        int array[] = {10, 10, 10};
        System.out.println(getSecodLargest(array));;
    }


    public Notification obj(String str){
        if(str.equals("mobile"))
            return new MobileNotification();

        if(str.equals("CRM"))
            return new SystemNotification();

        if(str.equals("internal"))
            return new InternalNotification();
        return null;
    }
    
    public static int getSecodLargest(int array[]){
        
        int max = array[0];
        int secondMax = Integer.MIN_VALUE;
        boolean flag = false;
        for(int i =0; i< array.length; i++){
            if(array[i] > max)
            {
                max = array[i];
            }
            else if(secondMax < array[i] && max > array[i])
            {
                secondMax = array[i];
                flag = true;
            }
        }
        if(flag) return secondMax;
        return -1;
    }
    
}


