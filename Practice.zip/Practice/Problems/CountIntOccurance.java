package Problems;

import java.util.HashSet;
import java.util.Set;

public class CountIntOccurance {

    public static void main(String[] args) {
        findOccuranceInNonOrdered();
    }
    
    public static void findOccuranceInOrdered(){
        int array[] = {1,2,2,3,3,4,4,4,5,5,7,1,1};
        int count = 1;
        for(int i = 1; i < array.length; i++){
            if(array[i] == array[i-1])
                count++;
            else{
                System.out.println(array[i-1] + "  "+ count);
                count = 1;
            }
        }
        System.out.println(array[array.length-1] + "  " + count);
    }

    public static void findOccuranceInNonOrdered(){
        int array[] = {1,2,2,3,3,4,4,4,5,5,7,1,1,7};
        int count = 0;
        Set<Integer> set = new HashSet<>();
        for(int i = 0; i < array.length; i++){
            if(set.add(array[i]))
                count = 1;
            else
                count++;
            System.out.println(array[i] + "  " + count);
        }
        // System.out.println(array[array.length-1] + "  " + count);
    }
}
