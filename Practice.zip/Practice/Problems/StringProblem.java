package Problems;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class StringProblem {

/*You are given a string s representing an expression containing various types of brackets: {}, (), and []. Your task is to determine whether the brackets in the expression are balanced. A balanced expression is one where every opening bracket has a corresponding closing bracket in the correct order.
 
Examples :
 
Input: s = "{([])}"
Output: true
Explanation: 
- In this expression, every opening bracket has a corresponding closing bracket.
- The first bracket { is closed by }, the second opening bracket ( is closed by ), and the third opening bracket [ is closed by ].
- As all brackets are properly paired and closed in the correct order, the expression is considered balanced.
 
Input: s = "()"
Output: true
Explanation: 
- This expression contains only one type of bracket, the parentheses ( and ).
- The opening bracket ( is matched with its corresponding closing bracket ).
- Since they form a complete pair, the expression is balanced.
 
Input: s = "([]"
Output: false
Explanation: 
- This expression contains only one type of bracket, the parentheses ( and ).
- The opening bracket ( is matched with its corresponding closing bracket ).
- Since they form a complete pair, the expression is balanced.
 
Constraints:
1 ≤ s.size() ≤ 106
s[i] ∈ {'{', '}', '(', ')', '[', ']'} 
    */ 



    public static void main(String[] args) {
        
       
        String str = "{([])}";
        balancedOrNot(str);
        // String str = "{{}}}}}";


    }

    public static boolean balancedOrNot(String input){
        
        Stack<Character> stack = new Stack<Character>();

        for(int i=0; i< input.length(); i++){

            
            char ch = input.charAt(i);
            if(ch == ')' && stack.peek() == '(')
                stack.pop();
            else if(ch == '}' && stack.peek() == '{')
                stack.pop();
            else if(ch == ']' && stack.peek() == '[')
                stack.pop();
            else stack.push(ch);

        }
        if(stack.size() == 0 && !input.equals(""))   return true;

        return false;

    }

    // 7 7 3 2 3 5

   
    
}
