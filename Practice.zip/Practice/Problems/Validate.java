package Problems;

public class Validate {

    private static Validate instance;

    private Validate(){}

    public static Validate getInstance(){
       if(instance != null){
        synchronized(Validate.class) {
            if(instance != null){
                instance = new Validate();
            }
        }
       }
       return instance;
    }

}