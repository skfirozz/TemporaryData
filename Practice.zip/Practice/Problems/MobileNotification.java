package Problems;

public class MobileNotification implements Notification{
     
    @Override
    public void sendData(String message) {
        // TODO Auto-generated method stub 
    }
}


class SystemNotification implements Notification{
     
    @Override
    public void sendData(String message) {
        // TODO Auto-generated method stub  
    }
}
 class InternalNotification implements Notification{
     
    @Override
    public void sendData(String message) {
        // TODO Auto-generated method stub
    }
}