package Problems;

public interface Notification {

    public void sendData(String message);
    
}