import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Cangra {

    public static void main(String[] args) {
        
        List<Integer> list=Arrays.asList(12,20,7,30,40,15);
        System.out.println(list.stream()
        .max(Comparator.naturalOrder()).get());

    }


    public static void sort(){
        List<String> listOfStrings = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");

        listOfStrings.stream()
                    .collect(Collectors.groupingBy( Function.identity(),  ));

    }
}