import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MostRepeatedNumber {

    
    public static void main(String[] args) {
        int arr[] = {5, 7, 5, 7, 5, 2};

        System.out.println(Arrays.stream(arr)
        .boxed()
        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
        .entrySet().stream()
        .sorted());;


    }
    
}
