import java.util.Stack;

public class DemoProgram {


    public static void main(String[] args) {
     
        
        int array[] = {3,6,1,0};

        // System.out.println(getVal(array));
        String str = "{{{}}}]";
        System.out.println(isBalanced(str));

    }


    public static int getValue(int array[]){

        // if */

        int max = array[0];
        int secondMax = Integer.MIN_VALUE;
        int index = 0;
        for(int i = 0; i< array.length; i++){

            if(max < array[i] ){
                max = array[i];
                index = i;
            }
            else if(secondMax < array[i] && max > array[i]){
                secondMax = array[i];
            }
        }
        System.out.println(secondMax);
        if(secondMax * 2 >= max)
            return index;
        return -1;
    }

    public static int getVal(int array[]){
        int max = array[0];
        int index = 0;
        for(int i =0; i< array.length; i++){
            if(max < array[i]){
                max = array[i];
                index = i;
            }
        }
        for(int i =0; i< array.length; i++){
            if(max >= array[i] * 2 && index != i){
                continue;
            }
            else if(index != i)    return -1;
        }
        return index;
    }


    public static boolean isBalanced(String str){
        if(str.length() <= 1) return false;

        Stack<Character> stack = new Stack<>();
        for(int i =0; i< str.length(); i++){
            
            char ch = str.charAt(i);
            if(ch == '{' || ch == '(' || ch == '['){
                stack.push(ch);
            }
            else if(!stack.isEmpty() && ch == ')' && stack.peek() == '(' ){
                stack.pop();
            }
            else if(!stack.isEmpty() && ch == '}' && stack.peek() == '{'){
                stack.pop();
            }
            else if(!stack.isEmpty() && ch == ']' && stack.peek() == '['){
                stack.pop();
            }else return false;
        }
        if(stack.isEmpty())
            return true;
        return false;
    }

    
}


/*
 * 
 * You are given an integer array nums where the largest integer is unique. 
 * Determine whether the largest element in the array is at least twice as much as every other number in the array. 
 * If it is, return the index of the largest element, or return -1 otherwise. 
 * Example 1: Input: nums = [3,6,1,0] Output: 1 Explanation: 6 is the largest integer.
 *  For every other number in the array x, 6 is at least twice as big as x. The index of value 6 is 1,
 *  so we return 1.
 *  Example 2: Input: nums = [1,2,3,4] Output: -1
 *  Explanation: 4 is less than twice the value of 3, so we return -1.
 *  Constraints: 2 <= nums.length <= 50 0 <= nums[i] <= 100 The largest element in nums is unique.


 * 
*/

/*
 * 
 * Gayathri A  2:24 PM

Write a function to determine if the given string containing characters '(', ')', '{', '}', '[' and ']' is balanced.
 A string is considered balanced if each type of bracket is opened and closed in the corresponding order and 
 they correctly nest. Requirements: The function should return true if the string is balanced, 
 otherwise return false. Implement the solution using a stack data structure to keep track of the opening brackets.
  Example: Input: "{[()]}" Output: true Input: "{[(])}" Output: false
 * 
*/

/*
 *
 * Employee table has salary 
second highest salary

select * from 


SELECT DISTINCT(SALARY)
FROM EMPLOYEE
ORDER BY salary DESC
offset 1 limit 1
 * 
*/
