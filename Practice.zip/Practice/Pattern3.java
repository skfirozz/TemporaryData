
public class Pattern3 {
    public static void main(String[] args) {
        int number = 6;
        int startNumber = 1;
        int array[][] = new int[number][number];
        for(int i =0; i<number; i++){
            int index = i;
            for(int j=0; j<number-i; j++){
                array[index][j] = startNumber++;
                index++;
            }
        }

        for(int x = 0; x <array.length; x++){
            for(int y = 0; y<= x; y++ ){
                System.out.print( array[x][y]+"   ");
            }
            System.out.println();
        }
        System.out.println("\n\n\n");
    }
    
}
