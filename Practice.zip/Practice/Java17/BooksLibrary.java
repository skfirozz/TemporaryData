package Java17;

public final class BooksLibrary {

   int id;
   String bookName;

    public BooksLibrary(String name, int num){
        id = num;
        bookName = name;
    }

    public String getName(){
        return bookName;
    }

    public int getId(){
        return id;
    }
}


/* check sts call back function in kafka which is provided by springbootx*/