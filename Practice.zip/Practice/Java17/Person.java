package Java17;

public record Person(String str, int age, int salary) {
    // No need for explicit constructor, getter methods, etc.
}


