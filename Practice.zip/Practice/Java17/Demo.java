package Java17;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Demo {

    public static void main(String[] args) {

        int[] arr = {1, 1, 1, 1, 1};
        System.out.println(countClumps(arr));

    }

    public static int countClumps(int[] nums) {
  
        int count = 0;
        boolean b = false;
        for(int i =0; i < nums.length-1; i++){
          if((nums[i] == nums[i+1]) && b == false ){
            count = count +1;
            System.out.println("gey  " + i );
            b = true;
          }else if(b == true && (nums[i] != nums[i+1])){
            System.out.println("else  " + i );
            b = false;
          }
        }
        return count;
      }
    // public static List<>
}
