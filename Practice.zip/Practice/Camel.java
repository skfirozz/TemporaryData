import java.util.Arrays;
import java.util.stream.Collectors;

public class Camel {


    public static void main(String[] args) {
        String str = "camel case word";

        String res = Arrays.stream(str.split(" "))
                .map(i -> fun(i))
                .collect(Collectors.joining(""));
                System.out.println(res);
            }

    public static String fun(String str){
        String res = str.charAt(0)+"";
        res = res.toUpperCase();

        res = res+str.substring(1, str.length());
        return res;
    }

}
