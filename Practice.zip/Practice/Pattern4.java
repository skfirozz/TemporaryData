public class Pattern4 {
    
}
