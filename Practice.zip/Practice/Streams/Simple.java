package Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Simple {

    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(
        new Employee(0, "a"),
        new Employee(1, "b"),
        new Employee(2, "c"),
        new Employee(3, "d"),
        new Employee(4, "e"),
        new Employee(5, "f"),
        new Employee(6, "g"),
        new Employee(7, "h"));


        // list.stream().mapToInt(Employee::getAge).sum();

        long d  = list.stream().filter(i -> i.getAge() %2 == 0).mapToInt(Employee::getAge).sum();
        System.out.println(d);
        // list.stream().filter(i -> i.getAge() %2 == 0).forEach(i -> System.out.println(i.getAge()));

        String str = list.stream().map(Employee::getName).collect(Collectors.joining(""));
        System.out.println(str);


        String temp = list.stream().filter(obj -> (obj.name.charAt(0) >= 'a' && obj.name.charAt(0) <= 'd') == true ).map(Employee::getName).skip(2).collect(Collectors.joining(" "));

        System.out.println(temp);




    }
    
}