package Streams;

import java.util.stream.IntStream;

public class EvenOdd {

    public static void main(String[] args) {
        
        IntStream.rangeClosed(1, 10).filter(i -> i%2 == 0).forEach(i -> System.out.println(i));
    }
    
}
