package Streams;

import java.lang.ref.WeakReference;
import java.time.Instant;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class EmployeeStream {
    
    public static void main(String[] args) {

        List<StreamEmployee> list = Arrays.asList(
            new StreamEmployee(1, "Ashiq", "ashqieq@gmail.com", 1, 100),
            new StreamEmployee(1, "irfan", "irfan@gmail.com", 1, 200),
            new StreamEmployee(1, "arshiya", "arshiya@gmail.com", 1, 300),
            new StreamEmployee(1, "mod", "mod@gmail.com", 2, 400),
            new StreamEmployee(1, "janbee", "janbee@gmail.com", 2, 500),
            new StreamEmployee(1, "baji", "baji@gmail.com", 3, 600),
            new StreamEmployee(1, "ershad", "ershad@gmail.com", 3, 700),
            new StreamEmployee(1, "nafisa", "nafisa@gmail.com", 4, 800),
            new StreamEmployee(1, "shamsheer", "shamsheer@gmail.com", 4, 900),
            new StreamEmployee(1, "saleem", "saleem@gmail.com", 5, 1000),
            new StreamEmployee(1, "shaik", "shaik@gmail.com", 5, 1100),
            new StreamEmployee(1, "firoz", "firoz@gmail.com", 6, 1200),
            new StreamEmployee(1, "shahid", "ashqieq@gmail.com", 6, 1300),
            new StreamEmployee(1, "altaf", "altaf@gmail.com", 6, 1400),
            new StreamEmployee(1, "budi", "budi@gmail.com", 6, 1500),
            new StreamEmployee(1, "karishma", "karishma@gmail.com", 7, 1600),
            new StreamEmployee(1, "shannu", "shannu@gmail.com", 7, 1700),
            new StreamEmployee(1, "sonu", "sonu@gmail.com", 7, 1800),
            new StreamEmployee(1, "sahil", "sahil@gmail.com", 8, 1900),
            new StreamEmployee(1, "shahida", "shahida@gmail.com", 8, 2000),
            new StreamEmployee(1, "naziya", "naziya@gmail.com", 8, 2100),
            new StreamEmployee(1, "ammi", "ammi@gmail.com", 8, 2200),
            new StreamEmployee(1, "abba", "abba@gmail.com", 9, 2300)
        );

        // WeakReference<Object> obj = new WeakReference<>();

        Map<Integer, StreamEmployee> map = list.stream()
                                        .collect(Collectors.groupingBy( StreamEmployee::getDepartmentNo,
                                                                        Collectors.collectingAndThen(
                                                                            Collectors.maxBy(Comparator.comparingDouble(StreamEmployee::getSalary)),
                                                                            Optional::orElseThrow )
                                                                    ));
        for (Map.Entry<Integer, StreamEmployee> d: map.entrySet()) {
            System.out.println(d.toString());
        }

    }


    public static List<StreamEmployee> getEmployeeList(int range){
        
        List<StreamEmployee> list = IntStream.rangeClosed(1, range)
                                            .mapToObj(i -> new StreamEmployee(i, "Employee" + i, "emp" + i + "@company.com", (i % 5) + 1, 30000 + (i * 1000)))
                                            .collect(Collectors.toList());
        return list;
    }



}

class StreamEmployee{
    int id;
    String name;
    String email;
    int departmentNo;
    double salary;
    Instant createdOn;
    Instant updatedOn;

    public StreamEmployee(int id, String name, String email, int departmentNo, double salary) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.departmentNo = departmentNo;
        this.salary = salary;
        this.createdOn = Instant.now();
        this.updatedOn = Instant.now();
    }

    
    public int getId() {
        return id;
    }


    public String getName() {
        return name;
    }


    public String getEmail() {
        return email;
    }


    public int getDepartmentNo() {
        return departmentNo;
    }


    public double getSalary() {
        return salary;
    }


    public Instant getCreatedOn() {
        return createdOn;
    }


    public Instant getUpdatedOn() {
        return updatedOn;
    }


    @Override
    public String toString() {
        return id + " - " + name + " - " + email + " - " + departmentNo + " - " + salary;
    }
}
