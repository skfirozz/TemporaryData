package Streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ReverseOfArray {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList( 1,4,5,2,43,23,44,245,11,76,0,9,4 );

        System.out.println(list.stream().sorted((o1, o2) -> o2.compareTo(o1) ).toList());;
        System.out.println(list.stream().sorted(Comparator.reverseOrder()).toList());
    }
}