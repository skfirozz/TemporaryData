package Streams;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class OccurancesOfChars {

    public static void main(String[] args) {
        String str = "jello there how are you man im dfoing ghreat";
        countOccurancesStreams(str);
        
        // countOccurancesStreams(str);
    }

    public static void countOccurancesStreams(String str){
        Map<Character, Long> map =  str.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(map);
    }

    public static void firstNonRepeatedChar(String str ){
        Map<Character, Long> map = str.chars().mapToObj(c -> (char) c ).collect(Collectors.groupingBy(c -> c, LinkedHashMap::new, Collectors.counting()));
        char ch = map.entrySet().stream().filter(value -> value.getValue() == 1).map(Map.Entry::getKey).findFirst().orElse(null);
        System.out.println(ch);
    }

    

    public static void countOccurances(String str){
        HashMap<Character, Integer> map = new HashMap<>();
        str = str.replaceAll(" ", "");
        System.out.println(str);
        for(int i = 0; i< str.length(); i++){
            char ch = str.charAt(i);
            if(map.containsKey(ch)){
                map.put(ch, map.get(ch)+1);
            }
            else map.put(ch, 1);
        }

        TreeMap<Character, Integer> treeMap = new TreeMap<>(map);
        

        System.out.println(map);

        System.out.println(treeMap);
    }
}