package Streams;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StringProblem {

    public static void main(String[] args) {
        reverseOfString();
        // reverseOfWord();
    }


    public static void reverseOfString(){
        String str = "shannu";
        StringBuilder sb = new StringBuilder();
        
        IntStream.range(0, str.length())
        .filter(i -> Arrays.asList('a', 'e', 'i', 'o', 'u').contains(str.charAt(i)))
        .forEach(i -> sb.append(str.charAt(str.length()-1-i)));
        System.out.println(sb.toString());

    }

    

    public static void reverseOfWord(){
        String str = "My name is suhana";
        String s =  Arrays.stream(str.split(" ")).map(i -> new StringBuilder(i).reverse()).collect(Collectors.joining(" "));
        
        System.out.println(s);
    }
    
}
