package Streams;

public class BinarySearch {

    public static void main(String[] args) {
        int[] sortedArray = {10, 20, 30, 40, 50, 60, 70, 80};

        int target = 50;

        System.out.println(binarySearch(sortedArray, target));
        
    }

    public static int binarySearch(int array[], int target ){
        int left = 0, right = array.length -1 ;
        while(left <= right){
            int mid = left + (right - left)/2;
            if(array[mid] == target)
                return mid;
            if(array[mid] > target)
                right = mid - 1;
            else left = mid +1;
        }
        return -1;
    }
    
}

