package Streams;

import java.util.stream.IntStream;

public class EvenNumbers {

    public static void main(String[] args) {
        
        long res = IntStream.rangeClosed(1, 100)
                .filter(i -> i%2 == 0)
                .count();
        System.out.println(res);
    }
    
}
