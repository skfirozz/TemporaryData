package Streams;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ListOfMapEntries {


    public static void main(String[] args) {
        List<Emp> list = Arrays.asList(new Emp("firoz", 19), 
                                        new Emp("shaik", 10));

        List<Map.Entry<String, Integer>> res= list.stream()
                                                .map(i -> new AbstractMap.SimpleEntry<>(i.getName(), i.getAge()))
                                                .collect(Collectors.toList());

        
    }

    
}

class Emp{
    String name;
    int age;

    Emp(String n, int a){
        name = n;
        age = a;
    }

    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }

    
}
