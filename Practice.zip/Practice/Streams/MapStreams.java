package Streams;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class MapStreams {

    public static void main(String[] args) {
        
        String str = "helloworldhowareyou";
        Map<Character, Long> map = str.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
    }

    public static void func(){
        List<Employee> list = Arrays.asList(
            new Employee(1, "a"),
            new Employee(2, "b"),
            new Employee(3, "c"),
            new Employee(4, "d"),
            new Employee(5, "e"),
            new Employee(6, "f"),
            new Employee(7, "g")
        ) ;

        List<Student> studentList = list.stream()
                                        .map(i -> new Student(i.getAge(), i.getName()))
                                        .toList();

        
        for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
            System.out.println("Garbage Collector: " + gc.getName());
        }
    }
}
