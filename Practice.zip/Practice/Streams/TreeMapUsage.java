package Streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class TreeMapUsage {

    
    public static void main(String[] args) {
        TreeMap<String, Integer> treemap = new TreeMap<>();
        List<String> strings = Arrays.asList("banana", "apple", "orange", "grape");
        for (String str : strings) {
            treemap.put(str, str.length());
        }

        List<String> sortedStrings = new ArrayList<>(treemap.keySet());
        System.out.println(sortedStrings);


        TreeMap<String, Integer> tmap = strings.stream().collect(
            Collectors.toMap(
                str -> str, 
                str -> str.length(),
                (oldValue, newValue)-> oldValue,
                TreeMap::new
                ));

        
    }
}