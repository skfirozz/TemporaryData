package Streams;

import java.util.ArrayList;
import java.util.LinkedList;

public class CustomHashMap<K, V1, V2> {
    private class Entry{
        K key;
        V1 value1;
        V2 value2;
        
        Entry(K k, V1 va1, V2 val2){
            this.key = k;
            this.value1 = va1;
            this.value2 = val2;
        }
    }

    private final int capacity = 16;
    private final ArrayList<LinkedList<Entry>> buckets;

    public CustomHashMap(){
        buckets = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            buckets.add(new LinkedList<>());
        }
    }

    private int getBucketIndex(K key){
        return Math.abs(key.hashCode()) % capacity;
    }

    public void put(K key, V1 value1, V2 value2){
        int bucketIndex = getBucketIndex(key);
        LinkedList<Entry> bucket = buckets.get(bucketIndex);
        for(Entry entr: bucket){
            if(entr.key.equals(key)){
                entr.value1 = value1;
                entr.value2 = value2;
                return;
            }
        }
        bucket.add(new Entry(key, value1, value2));
    }


    
}
