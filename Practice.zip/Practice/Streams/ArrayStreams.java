package Streams;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ArrayStreams {
    public static void main(String[] args) {
        int array[] = {1,2,3,4,5,1,2};
        // removeDuplicates(array);
        // onlyDistinct(array);
        // findDuplicates(array);
        // findDuplicatesSet(array);

        String data[] = {"hi", "hi", "hello", "hey", "there", "hey", "how", "are", "you", "do"};
        uniqueString(data);

    }

    public static void uniqueString(String data[]){
        String dd[] = Arrays.stream(data)
                        .distinct()
                        .map(i -> i)
                        .toArray(String[]::new);

        System.out.println(Arrays.toString(dd));


    }

    public static void removeDuplicates(int array[]){
        int resultp[] = Arrays.stream(array)
                            .boxed()
                            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                            .entrySet()
                            .stream()
                            .filter(i -> i.getValue() == 1)
                            .map(i -> i.getKey())
                            .mapToInt(Integer::intValue)
                            .toArray();

        System.out.println(Arrays.toString(resultp));
    }

    public static void onlyDistinct(int array[]){

        int resultp[] = Arrays.stream(array)
                        .boxed()
                        .distinct()
                        .mapToInt(i -> i)
                        .toArray();

        System.out.println(Arrays.toString(resultp));
    }

    public static void findDuplicatesSet(int array[]){
        
        Set<Integer> set = new HashSet<>();
        int result[] = Arrays.stream(array)
                        .boxed()
                        .filter(i -> !set.add(i))
                        .mapToInt(Integer::intValue)
                        .toArray();

        System.out.println(Arrays.toString(result));
    }

    public static void findDuplicates(int array[]){
        int result[] = Arrays.stream(array)
                            .boxed()
                            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                            .entrySet()
                            .stream()
                            .filter(i -> i.getValue() > 1)
                            .map(i -> i.getKey())
                            .mapToInt(Integer::intValue)
                            .toArray();

        System.out.println(Arrays.toString(result));
    }

    public static void moveZerosToEnd(int array[]){
        int index = 0;
        for(int i =0; i< array.length; i++){

            if(array[i] != 0){
                
                index++;
            }

        }
    }
}

