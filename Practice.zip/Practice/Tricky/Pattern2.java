package Tricky;

import java.util.HashSet;
import java.util.Set;

public class Pattern2 {

    public static void main(String[] args) {
            int number = 6;
            int value = 1;
            int inc = 2;
            right(number, value, inc);
        
        }

    public static void left(int number, int value, int inc){
        int[][] array = new int[number][number];
        Set<Integer> set = new HashSet<>();
        for(int i = 0; i< number; i++){
            while(set.contains(value)){
                value++;
                if(set.contains(value))
                    continue;
                break;
            }
            int temp = value;
            for(int j = 0; j<= i; j++){
                // System.out.print(temp+ "  ");
                set.add(temp);
                array[i][j] = temp;
                temp = temp + inc;
            }
            System.out.println();
        
        }

        for(int i = 0; i< number; i++){
            for(int j = 0; j <= i; j++){
                System.out.print(array[i][j]+"  ");
            }
            System.out.println();
        }
    }

    public static void right(int number, int value, int inc){
        int[][] array = new int[number][number];
        Set<Integer> set = new HashSet<>();
        for(int i = 0; i< number; i++){
            while(set.contains(value)){
                value++;
                if(set.contains(value))
                    continue;
                break;
            }
            int temp = value;
            for(int j = number-i; j<number; j++){
                System.out.print (temp+"  ");
                set.add(temp);
                array[i][j] = temp;
                temp = temp + inc;
            }
            System.out.println();
        
        }

        for(int i = 0; i< number; i++){
            for(int j = 0; j <number; j++){
                System.out.print(array[i][j]+"  ");
            }
            System.out.println();
        }
    }
}
