package Tricky;

public class CountClumps {

    public static void main(String[] args) {
        
        int array[] = {1, 1, 1, 1, 1};

        int index = 0;
        for(int i = 0; i< array.length-1; i++){
            if(array[i] == array[i+1]){
                index++;
                while(i < array.length -2 && array[i] == array[i+1]){
                    i++;
                }
            }
        }

        System.out.println("index  "+index);
    }
}