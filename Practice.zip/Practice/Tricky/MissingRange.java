package Tricky;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MissingRange {

    public static void main(String[] args) {
        int array[] = {0,1,3,50,75};
        int lower = -10;
        int upper = 99;
        List<List<Integer>> list = getMissingNumber(array, lower, upper);
        System.out.println(list);
    }

    public static List<List<Integer>> getMissingNumber(int array[], int lower, int upper){
        List<List<Integer>> list = new ArrayList<>();
        if(array.length == 0){
            list.add(Arrays.asList(lower, upper));
            return list;
        }

        if (lower < array[0]) {
            list.add(Arrays.asList(lower, array[0] - 1));
        }
        for (int i = 1; i < array.length; i++) {
            if(array[i] > upper){
                list.add(Arrays.asList(array[i - 1] + 1, upper));
                break;
            }
            if (array[i] > array[i - 1] + 1) {
                list.add(Arrays.asList(array[i - 1] + 1, array[i] - 1));
            }
        }
        if (upper > array[array.length - 1]) {
            list.add(Arrays.asList(array[array.length - 1] + 1, upper));
        }
        return list;
    }
    
}
