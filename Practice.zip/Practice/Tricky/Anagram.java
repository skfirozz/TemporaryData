package Tricky;

public class Anagram {

    public static void main(String[] args) {
        
        String str1 = "listen";
        String str2 = "silent";

        if(str1.length() != str2.length()) return;

        int xOrValue = 0;
        for(int i = 0; i<str1.length(); i++){
            xOrValue = xOrValue ^ str1.charAt(i);
            xOrValue = xOrValue ^ str2.charAt(i);
            System.out.println(xOrValue);
        }
    }
    
}
