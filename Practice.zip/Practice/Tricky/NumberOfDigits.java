package Tricky;

public class NumberOfDigits {

    public static void main(String[] args) {
        
        int number = 1234;

        int res = (int ) Math.log10(number) + 1;
        System.out.println(res);
    }
    
}
