package Tricky;

public class Pattern1 {
    public static void main(String[] args) {
        
        int number = 4;
        char ch= 'A';
        boolean b = true;
        for(int i =0; i< number; i++){
            if(i %2 ==0)
                b = true;
            else b = false;

            for(int j =0; j<= i; j++){
                if(b){
                    ch = Character.toUpperCase(ch);
                    b = false;
                }
                else {
                    ch= Character.toLowerCase(ch);
                    b= true;
                }

                System.out.print(ch++ +"  ");
            }
            System.out.println();
        }
    }
    
}
