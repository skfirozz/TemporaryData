package Tricky;

import java.util.Stack;

public class RemoveUnbalancedParentheses {

    public static void main(String[] args) {
        String str = "((abc)((de))";
        System.out.println(removeUnbalancedParentheses(str));  // Output: "((abc)(de))"
    }

    public static String removeUnbalancedParentheses(String str) {
        StringBuilder sb = new StringBuilder(str);
        Stack<Integer> stack = new Stack<>();
        for(int i =0; i< sb.length(); i++){
            if(sb.charAt(i) == '(')
                stack.push(i);
            else if(sb.charAt(i) == ')'){
                if(!stack.isEmpty())
                    stack.pop();
                else
                    sb.setCharAt(i, '*');
            }
        }
        while(!stack.empty()){
            sb.setCharAt(stack.pop(), '*');
        }
        return sb.toString().replace("*", "");
    }

    
    
}
