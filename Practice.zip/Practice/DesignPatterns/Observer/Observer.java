package DesignPatterns.Observer;

interface Observer {
    void update(String data);   
}
