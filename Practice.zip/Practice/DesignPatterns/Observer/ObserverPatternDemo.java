package DesignPatterns.Observer;

public class ObserverPatternDemo {

    public static void main(String[] args) {
        ApiSubject apiSubject = new ApiSubject();

        // Create observers
        Observer observer1 = new ApiObserver("Observer 1");
        Observer observer2 = new ApiObserver("Observer 2");

        // Register observers
        apiSubject.registerObserver(observer1);
        apiSubject.registerObserver(observer2);

        // Simulate state changes
        apiSubject.setData("API Response 1");
        apiSubject.setData("API Response 2");

        // Remove an observer
        apiSubject.removeObserver(observer1);

        // Simulate another state change
        apiSubject.setData("API Response 3");
    }
}
