package DesignPatterns.Observer;

import java.util.ArrayList;
import java.util.List;

public class ApiSubject implements Subject{

    private List<Observer> observers = new ArrayList<>();
    private String data;

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(data);
        }
    }

    public void setData(String newData) {
        this.data = newData;
        notifyObservers();
    }
}
