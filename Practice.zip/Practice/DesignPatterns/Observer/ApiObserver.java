package DesignPatterns.Observer;

public class ApiObserver implements Observer {

    private String name;

    public ApiObserver(String name) {
        this.name = name;
    }

    @Override
    public void update(String data) {
        System.out.println(name + " received update: " + data);
    }
}
